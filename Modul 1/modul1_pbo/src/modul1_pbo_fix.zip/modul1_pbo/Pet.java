/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul1_pbo;

import java.util.Random;

/**
 *
 * @author user
 */
public class Pet extends Mob{
        Random random = new Random();
        private Player player;
        

        Pet(String name){
            super.name = name;
            player = null;
        }
        
        public void ditangkap(Player nama_player){
            player = nama_player;
        }
        
        public void healing(Player p){
            if(p.hp<p.max_hp){
                int num = random.nextInt(2);
                if(num==1){
                    p.hp +=super.level*2;
                }
            }
        }
}
