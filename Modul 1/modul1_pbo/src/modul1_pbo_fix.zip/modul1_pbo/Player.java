package modul1_pbo;

public class Player extends Entity{
    Weapon weapon;
    private Pet pet;
    
    Player(String nama_player){
        super.name = nama_player;
        weapon = null;
        pet = null;
    }
    
    public void menyerangMonster(Monster nama_mosnter){
        if(weapon == null && pet==null){
            nama_mosnter.hp -= super.base_attack;
            super.exp += nama_mosnter.drop_xp();
                       
        }else if(pet==null){
            nama_mosnter.hp -= super.base_attack+ weapon.base_attack;
            int exp = nama_mosnter.drop_xp()/2;
            super.exp += exp;
            weapon.exp += exp;
                        
        }else if(weapon == null){
            nama_mosnter.hp -= super.base_attack+ pet.base_attack;
            int exp = nama_mosnter.drop_xp()/2;
            super.exp += exp;
            pet.exp += exp;
        }else{
            nama_mosnter.hp -= super.base_attack+ weapon.base_attack +pet.base_attack;
            nama_mosnter.serangPet(pet);
            int exp = nama_mosnter.drop_xp()/3;
            super.exp += exp;
            weapon.exp += exp;
            pet.exp += exp;
        }
        nama_mosnter.serangPlayer(this);
        if(pet != null){
            pet.healing(this);
            pet.naiklevel();
        }if(weapon != null){
            weapon.naiklevel();
        }
        super.naiklevel();
        
        gameOver();
    }
    
    public void menangkapPet(Pet nama_pet){
        pet = nama_pet;
    }
    
    public void menggunakanWeapon(Weapon nama_senjata){
        weapon = nama_senjata;
    }
    
    
    public void gameOver(){
        if(hp<=0){
            System.out.println("Game Over");
        }
    }
    
    public void getplayer(){
        System.out.println("----------------------------------------------------");
        System.out.println("Nama          : "+super.name+
                           "\nBase attack : "+super.base_attack+
                           "\nlevel       : "+super.level+
                           "\nHP          : "+super.hp+
                           "\nEXP         : "+super.exp+"\n\n");
        System.out.println("----------------------------------------------------");
    }
    
    public void getSenjata(){
        System.out.println("----------------------------------------------------");
        System.out.println("Nama          : "+weapon.name+
                           "\nBase attack : "+weapon.base_attack+
                           "\nlevel       : "+weapon.level+
                           "\nHP          : "+weapon.hp+
                           "\nEXP         : "+weapon.exp+"\n\n");
        System.out.println("----------------------------------------------------");
    }
    
    public void getPet(){
        System.out.println("----------------------------------------------------");
        System.out.println("Nama          : "+pet.name+
                           "\nBase attack : "+pet.base_attack+
                           "\nlevel       : "+pet.level+
                           "\nHP          : "+pet.hp+
                            "\nEXP         : "+pet.exp+"\n\n");
        System.out.println("----------------------------------------------------");
    }
}
