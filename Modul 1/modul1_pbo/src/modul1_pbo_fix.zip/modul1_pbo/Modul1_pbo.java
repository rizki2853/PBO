package modul1_pbo;

public class Modul1_pbo {

    public static void main(String[] args) {
        //membuat player
        Player p1 = new Player("Rizki");
        Player p2 = new Player("zero");
        
        //membuat senjata
        Weapon w1 = new Weapon("pedang");
        Weapon w2 = new Weapon("tombak");
        Weapon w3 = new Weapon("Pisau");
        
        //membuat pet
        Pet pet1 = new Pet("Pikachu");
        Pet pet2 = new Pet("raiju");
        Pet pet3 = new Pet("togepi");
        
        //membuat monster
        Monster m1 = new Monster("Kaijuu");
        Monster m2 = new Monster("Kaijuu no kodomo");
        Monster m3 = new Monster("Ghoul");
        Monster m4 = new Monster("Titan");
        Monster m5 = new Monster("Hollow");
        
        p1.getplayer();
        
        //menyerang tanpa senjata
        p1.menyerangMonster(m2);
        
        //mengambil weapon
        p1.menggunakanWeapon(w1);
        
        //menyerang tanpa senjata
        p1.menyerangMonster(m2);
        
        //menangkap pet
        p1.menangkapPet(pet2);
        
        //menyerang menggunakan pet dan weapon
        p1.menyerangMonster(m2);
        
        //status player
        
        //status senjata
//        p1.getSenjata();
        
        //serang sampai level 2 dan pet mati

        //status pemain
        p1.getplayer();
        p1.getSenjata();
        p1.getPet();
        
        p1.menyerangMonster(m1);
        p1.menyerangMonster(m1);
        
        p1.getplayer();
        p1.getSenjata();
        p1.getPet();
        
        p1.menyerangMonster(m3);
        p1.menyerangMonster(m3);
        
        p1.getplayer();
        p1.getSenjata();
        p1.getPet();
        
        m3.detailmonster();
        
        //detail monster
//        m2.detailmonster();
        
        
        
        

        
    }
    
}
