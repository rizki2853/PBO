package modul1_pbo;

public class Monster extends Mob{
        
        Monster(String nama_monster){
            super.name = nama_monster;
        }
        
        public void serangPlayer(Player Nama_player){
            Nama_player.hp -= super.base_attack;
        }
        
        public void serangPet(Pet Nama_pet){
            Nama_pet.hp -= super.base_attack;
            if(super.hp >0){
                super.exp +=Nama_pet.drop_xp();
            }   
        }
        
        
}
